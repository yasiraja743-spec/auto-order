# ONYX AUTO ORDER + DOCKER VPS NAT

## 1. Provider
cd provider
chmod +x install.sh
sudo ./install.sh

Edit provider/config.js:
PUBLIC_IP = "152.55.180.252"
API_KEY = "7S4zx0-1IFWT3tMQpKT2eB6z3deHjKUUcJOvy8XAlxVvNmRs"

Start:
npm start

## 2. Bot
cd bot
npm install
nano config.js

Set:
BOT_TOKEN = token from @BotFather
ADMIN_ID = your Telegram numeric ID

Provider is already connected to:
http://152.55.180.252:8080
with the matching API key.

Start:
npm start

## Important
Open TCP 8080 to the bot only if possible. Do not expose Docker socket.
Make sure the provider VPS firewall/security group allows the API connection.
