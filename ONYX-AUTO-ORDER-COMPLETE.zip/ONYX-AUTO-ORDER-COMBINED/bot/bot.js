const axios = require("axios");
const fs = require("fs");
const path = require("path");
const config = require("./config");

const API = `https://api.telegram.org/bot${config.BOT_TOKEN}`;
const DATA = path.join(__dirname, "data");
const ORDERS = path.join(DATA, "orders.json");
fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(ORDERS)) fs.writeFileSync(ORDERS, "[]");

const sessions = new Map();

function loadOrders() { return JSON.parse(fs.readFileSync(ORDERS, "utf8")); }
function saveOrders(x) { fs.writeFileSync(ORDERS, JSON.stringify(x, null, 2)); }

async function tg(method, payload = {}) {
  const r = await axios.post(`${API}/${method}`, payload, { timeout: 60000 });
  if (!r.data.ok) throw new Error(r.data.description || "Telegram API error");
  return r.data.result;
}

async function sendMessage(chat_id, text, extra = {}) {
  return tg("sendMessage", { chat_id, text, parse_mode: "HTML", ...extra });
}

async function isMember(userId) {
  try {
    const r = await tg("getChatMember", { chat_id: config.FORCE_CHANNEL, user_id: userId });
    return ["creator", "administrator", "member"].includes(r.status);
  } catch { return false; }
}

async function mainMenu(chatId, name) {
  return tg("sendPhoto", {
    chat_id: chatId,
    photo: "https://files.catbox.moe/9cs2g7.jpg",
    caption:
`<b>AUTO ORDER VPS NAT</b>

<b>ONYX VPS AUTO ORDER</b>
HARGA SETIAP VPS <b>Rp${config.VPS_PRICE}</b>
ADA TOOLS BUAT VPS KALIAN

Halo <b>${escapeHtml(name)}</b> 👋`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "🛒 Buy VPS", callback_data: "buy_vps", style: "primary" },
        { text: "🛠 Tools VPS", callback_data: "tools_vps", style: "primary" }
      ]]
    }
  });
}

function escapeHtml(s) {
  return String(s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

async function start(chatId, user) {
  if (!(await isMember(user.id))) {
    return sendMessage(chatId,
`<b>🔒 AKSES TERKUNCI</b>

Silakan join channel <b>${config.FORCE_CHANNEL}</b> terlebih dahulu.`,
      { reply_markup: { inline_keyboard: [
        [{ text: "📢 Join Channel", url: "https://t.me/onyxkyro" }],
        [{ text: "✅ Sudah Join", callback_data: "check_join" }]
      ]}}
    );
  }
  return mainMenu(chatId, user.first_name || user.username || "User");
}

async function createProviderVps() {
  const r = await axios.post(`${config.PROVIDER_URL}/api/vps/create`, {}, {
    headers: { "X-API-Key": config.PROVIDER_API_KEY },
    timeout: 180000
  });
  if (!r.data.success) throw new Error(r.data.message || "Provider gagal membuat VPS");
  return r.data.vps;
}

async function handleMessage(m) {
  if (!m.message) return;
  const msg = m.message;
  const chatId = msg.chat.id;
  const user = msg.from;
  const text = msg.text || "";

  if (text === "/start") {
    sessions.delete(chatId);
    return start(chatId, user);
  }

  const s = sessions.get(chatId);

  if (s?.type === "tools_ip" && text) {
    s.ip = text.trim();
    s.type = "tools_port";
    return sendMessage(chatId, "Masukkan <b>port SSH</b> VPS:");
  }

  if (s?.type === "tools_port" && text) {
    const port = Number(text.trim());
    if (!Number.isInteger(port) || port < 1 || port > 65535)
      return sendMessage(chatId, "Port tidak valid.");
    s.port = port;
    s.type = "tools_password";
    return sendMessage(chatId, "Masukkan <b>password VPS</b>:");
  }

  if (s?.type === "tools_password" && text) {
    s.password = text;
    s.type = "tools_file";
    return sendMessage(chatId, "Sekarang kirim <b>file</b> yang mau di-upload.");
  }

  if (s?.type === "tools_file" && msg.document) {
    return sendMessage(chatId,
      "Fitur upload Tools VPS membutuhkan kredensial SSH/SFTP yang benar-benar dapat dijangkau dari provider. Implementasi upload aman bisa ditambahkan setelah endpoint SSH target ditentukan.");
  }

  if (s?.type === "proof" && (msg.photo || msg.document)) {
    const orders = loadOrders();
    const order = {
      id: "ORD-" + Date.now(),
      userId: user.id,
      username: user.username || "-",
      name: user.first_name || "-",
      price: config.VPS_PRICE,
      status: "waiting_payment_confirmation",
      createdAt: new Date().toISOString()
    };
    orders.push(order);
    saveOrders(orders);
    sessions.delete(chatId);

    await sendMessage(chatId, "✅ Bukti pembayaran diterima. Tunggu admin melakukan verifikasi.");

    const adminText =
`<b>💰 PEMBAYARAN BARU</b>

Order: <code>${order.id}</code>
User: @${escapeHtml(order.username)}
ID: <code>${order.userId}</code>
Harga: <b>Rp${order.price}</b>

Pilih tindakan:`;

    await sendMessage(config.ADMIN_ID, adminText, {
      reply_markup: { inline_keyboard: [[
        { text: "✅ ACCEPT", callback_data: `accept:${order.id}`, style: "success" },
        { text: "❌ REJECT", callback_data: `reject:${order.id}`, style: "danger" }
      ]]}
    });
    return;
  }

  if (s?.type === "proof") return sendMessage(chatId, "Kirim bukti pembayaran berupa foto atau dokumen.");

  if (text === "/orders" && String(user.id) === String(config.ADMIN_ID)) {
    const orders = loadOrders().slice(-20).reverse();
    return sendMessage(chatId, orders.length
      ? orders.map(o => `${o.id} | ${o.status} | @${o.username}`).join("\n")
      : "Belum ada order.");
  }
}

async function handleCallback(q) {
  const chatId = q.message.chat.id;
  const data = q.data;
  await tg("answerCallbackQuery", { callback_query_id: q.id });

  if (data === "check_join") return start(chatId, q.from);

  if (data === "buy_vps") {
    sessions.set(chatId, { type: "proof" });
    return tg("sendPhoto", {
      chat_id: chatId,
      photo: "https://files.catbox.moe/flmxr0.jpg",
      caption: `<b>QRIS PEMBAYARAN</b>\n\nHarga VPS: <b>Rp${config.VPS_PRICE}</b>\n\nSetelah pembayaran, kirim bukti pembayaran di sini.`,
      parse_mode: "HTML"
    });
  }

  if (data === "tools_vps") {
    sessions.set(chatId, { type: "tools_ip" });
    return sendMessage(chatId, "<b>🛠 TOOLS VPS</b>\n\nMasukkan IP VPS:");
  }

  if (!data.startsWith("accept:") && !data.startsWith("reject:")) return;

  if (String(q.from.id) !== String(config.ADMIN_ID)) return sendMessage(chatId, "Unauthorized.");

  const [action, orderId] = data.split(":");
  const orders = loadOrders();
  const order = orders.find(o => o.id === orderId);
  if (!order) return sendMessage(chatId, "Order tidak ditemukan.");

  if (action === "reject") {
    order.status = "rejected";
    saveOrders(orders);
    await sendMessage(order.userId, `❌ Order <code>${order.id}</code> ditolak admin.`);
    return sendMessage(chatId, "Order ditolak.");
  }

  if (order.status !== "waiting_payment_confirmation")
    return sendMessage(chatId, "Order sudah diproses.");

  order.status = "provisioning";
  saveOrders(orders);
  await sendMessage(chatId, "⏳ Membuat VPS melalui provider...");

  try {
    const vps = await createProviderVps();
    order.status = "completed";
    order.vpsId = vps.id;
    saveOrders(orders);

    await sendMessage(order.userId,
`<b>🎉 PEMBELIAN BERHASIL</b>

<b>VPS DATA</b>
IP: <code>${escapeHtml(vps.ip)}</code>
Port: <code>${vps.port}</code>
Username: <code>${escapeHtml(vps.username)}</code>
Password: <code>${escapeHtml(vps.password)}</code>

Terima kasih sudah order di <b>ONYX VPS AUTO ORDER</b>.`);

    await sendMessage(config.LOG_CHANNEL,
`<b>💰 PEMBAYARAN BERHASIL</b>

Terimakasih kak @${escapeHtml(order.username)}
telah order di bot kami.

Barang yang dibeli: <b>VPS NAT</b>
Harga: <b>Rp${order.price}</b>`);
    return sendMessage(chatId, `✅ ${orderId} selesai. VPS ${vps.id} berhasil dibuat.`);
  } catch (e) {
    order.status = "provision_failed";
    order.error = e.message;
    saveOrders(orders);
    await sendMessage(order.userId, "⚠️ Pembayaran diterima, tetapi provisioning VPS gagal. Admin akan mengecek provider.");
    return sendMessage(chatId, "❌ Provider gagal membuat VPS: " + e.message);
  }
}

async function poll() {
  let offset = 0;
  console.log("ONYX Auto Order berjalan...");
  await tg("deleteWebhook", { drop_pending_updates: false }).catch(() => {});
  while (true) {
    try {
      const updates = await tg("getUpdates", {
        offset, timeout: 50,
        allowed_updates: ["message", "callback_query"]
      });
      for (const u of updates) {
        offset = u.update_id + 1;
        if (u.message) await handleMessage(u).catch(console.error);
        if (u.callback_query) await handleCallback(u.callback_query).catch(console.error);
      }
    } catch (e) {
      console.error("Polling:", e.message);
      await new Promise(r => setTimeout(r, 3000));
    }
  }
}

poll().catch(console.error);
