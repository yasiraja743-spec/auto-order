module.exports = {
  BOT_TOKEN: "ISI_TOKEN_BOTFATHER",
  ADMIN_ID: "ISI_ID_TELEGRAM_LU",
  FORCE_CHANNEL: "@onyxkyro",
  LOG_CHANNEL: "@onyxkyro",
  VPS_PRICE: 500,
  VPS_PASSWORD: "luciferXkyro",
  DEVELOPER: "@darkluclfer",
  PROVIDER_URL: "http://152.55.180.252:8080",
  PROVIDER_API_KEY: "7S4zx0-1IFWT3tMQpKT2eB6z3deHjKUUcJOvy8XAlxVvNmRs"
};
