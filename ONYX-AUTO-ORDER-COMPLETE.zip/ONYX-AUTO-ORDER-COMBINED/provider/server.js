const http = require("http");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const config = require("./config");

const DATA_DIR = path.dirname(path.resolve(config.DATA_FILE));
const DATA_FILE = path.resolve(config.DATA_FILE);

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "[]");

function loadVps() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return [];
  }
}

function saveVps(items) {
  const tmp = DATA_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(items, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

function run(cmd, args, options = {}) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { timeout: 120000, maxBuffer: 1024 * 1024, ...options },
      (error, stdout, stderr) => {
        if (error) {
          error.stdout = stdout;
          error.stderr = stderr;
          reject(error);
        } else {
          resolve({ stdout, stderr });
        }
      });
  });
}

function auth(req) {
  const key = req.headers["x-api-key"];
  return typeof key === "string" && key === config.API_KEY;
}

function send(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(payload)
  });
  res.end(payload);
}

function body(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > 1024 * 1024) {
        req.destroy();
        reject(new Error("Request too large"));
      }
    });
    req.on("end", () => {
      if (!data) return resolve({});
      try { resolve(JSON.parse(data)); }
      catch { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}

function randomId() {
  return "vps-" + Date.now().toString(36) + "-" +
    Math.random().toString(36).slice(2, 8);
}

function validName(s) {
  return typeof s === "string" && /^[a-zA-Z0-9_-]{1,40}$/.test(s);
}

async function allocatePort(items) {
  const used = new Set(items.map(x => Number(x.port)));
  for (let p = config.PORT_START; p <= config.PORT_END; p++) {
    if (!used.has(p)) {
      try {
        await run("ss", ["-ltnH", "sport", "=", `:${p}`]);
        // ss exits successfully even when there is no listener, so inspect output.
        const check = await run("ss", ["-ltnH"]);
        if (!check.stdout.split("\n").some(line => line.includes(`:${p} `) || line.includes(`:${p}\n`))) {
          return p;
        }
      } catch {}
    }
  }
  throw new Error("No free NAT port available");
}

async function ensureImage() {
  try {
    await run("docker", ["image", "inspect", config.DOCKER_IMAGE]);
  } catch {
    await run("docker", ["pull", config.DOCKER_IMAGE]);
  }
}

async function createVps() {
  const items = loadVps();
  const id = randomId();
  const container = "onyx-" + id.replace(/[^a-zA-Z0-9_-]/g, "-");
  const port = await allocatePort(items);

  await ensureImage();

  // Ubuntu container normally exits immediately without a long-running process.
  // systemd is intentionally not used; this is a lightweight container VPS.
  await run("docker", [
    "run", "-d",
    "--name", container,
    "--hostname", container,
    "--memory", config.MEMORY,
    "--cpus", config.CPU,
    "--pids-limit", "256",
    "--restart", "unless-stopped",
    "-p", `${port}:22`,
    config.DOCKER_IMAGE,
    "bash", "-lc",
    "apt-get update >/dev/null 2>&1 && DEBIAN_FRONTEND=noninteractive apt-get install -y openssh-server >/dev/null 2>&1 && mkdir -p /run/sshd && echo 'root:" + config.VPS_PASSWORD.replace(/'/g, "'\\''") + "' | chpasswd && sed -ri 's/^#?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config && sed -ri 's/^#?PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config && /usr/sbin/sshd -D"
  ]);

  const record = {
    id,
    container,
    ip: config.PUBLIC_IP,
    port,
    username: config.VPS_USERNAME,
    password: config.VPS_PASSWORD,
    memory: config.MEMORY,
    cpu: config.CPU,
    image: config.DOCKER_IMAGE,
    status: "running",
    createdAt: new Date().toISOString()
  };

  items.push(record);
  saveVps(items);
  return record;
}

async function getStatus(record) {
  try {
    const r = await run("docker", ["inspect", "-f", "{{.State.Status}}", record.container]);
    return r.stdout.trim();
  } catch {
    return "not_found";
  }
}

async function deleteVps(id) {
  const items = loadVps();
  const record = items.find(x => x.id === id);
  if (!record) throw new Error("VPS not found");

  try {
    await run("docker", ["rm", "-f", record.container]);
  } catch {}

  const remaining = items.filter(x => x.id !== id);
  saveVps(remaining);
  return record;
}

const server = http.createServer(async (req, res) => {
  try {
    if (!auth(req)) return send(res, 401, { success: false, message: "Unauthorized" });

    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

    if (req.method === "GET" && url.pathname === "/api/health") {
      return send(res, 200, { success: true, service: "onyx-provider" });
    }

    if (req.method === "POST" && url.pathname === "/api/vps/create") {
      const record = await createVps();
      return send(res, 201, {
        success: true,
        vps: {
          id: record.id,
          ip: record.ip,
          port: record.port,
          username: record.username,
          password: record.password,
          status: record.status
        }
      });
    }

    if (req.method === "GET" && url.pathname.startsWith("/api/vps/")) {
      const id = url.pathname.split("/").pop();
      const record = loadVps().find(x => x.id === id);
      if (!record) return send(res, 404, { success: false, message: "VPS not found" });

      const status = await getStatus(record);
      record.status = status;
      return send(res, 200, {
        success: true,
        vps: {
          id: record.id,
          ip: record.ip,
          port: record.port,
          username: record.username,
          password: record.password,
          status
        }
      });
    }

    if (req.method === "DELETE" && url.pathname.startsWith("/api/vps/")) {
      const id = url.pathname.split("/").pop();
      const record = await deleteVps(id);
      return send(res, 200, { success: true, deleted: record.id });
    }

    if (req.method === "GET" && url.pathname === "/api/vps") {
      const items = loadVps();
      const result = [];
      for (const item of items) {
        result.push({
          id: item.id,
          ip: item.ip,
          port: item.port,
          username: item.username,
          status: await getStatus(item),
          createdAt: item.createdAt
        });
      }
      return send(res, 200, { success: true, vps: result });
    }

    return send(res, 404, { success: false, message: "Not found" });
  } catch (err) {
    console.error(err);
    return send(res, 500, {
      success: false,
      message: err.message || "Internal server error"
    });
  }
});

server.listen(config.PORT, config.HOST, () => {
  console.log(`ONYX Provider API listening on ${config.HOST}:${config.PORT}`);
});
