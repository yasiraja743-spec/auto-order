module.exports = {
  // API listen
  HOST: "0.0.0.0",
  PORT: 8080,

  // Change this to a long random value.
  API_KEY: "7S4zx0-1IFWT3tMQpKT2eB6z3deHjKUUcJOvy8XAlxVvNmRs",

  // Public IPv4 address of this provider VPS.
  // Example: "152.55.181.59"
  PUBLIC_IP: "152.55.180.252",

  // Docker image used for customer instances.
  // Ubuntu 24.04 is used here.
  DOCKER_IMAGE: "ubuntu:24.04",

  // Default resource limits.
  MEMORY: "512m",
  CPU: "1.0",
  DISK_LIMIT: "5g",

  // NAT SSH port range on the provider VPS.
  PORT_START: 20000,
  PORT_END: 30000,

  // Default credentials returned by the API.
  VPS_USERNAME: "root",
  VPS_PASSWORD: "luciferXkyro",

  DATA_FILE: "./data/vps.json"
};
