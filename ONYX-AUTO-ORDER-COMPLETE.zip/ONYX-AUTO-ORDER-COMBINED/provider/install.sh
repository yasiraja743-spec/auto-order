#!/usr/bin/env bash
set -euo pipefail

echo "=== ONYX Docker VPS NAT Provider - Ubuntu 24.04 ==="

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo bash install.sh"
  exit 1
fi

apt-get update
apt-get install -y ca-certificates curl gnupg nodejs npm openssh-client

if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc

  . /etc/os-release
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
    ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list

  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

systemctl enable --now docker

cd "$(dirname "$0")"
npm install --omit=dev

echo
echo "Installation selesai."
echo "Edit config.js terlebih dahulu:"
echo "  PUBLIC_IP = IP publik VPS provider"
echo "  API_KEY   = key rahasia"
echo
echo "Start:"
echo "  npm start"
echo
echo "Test:"
echo "  curl -H 'X-API-Key: YOUR_KEY' http://127.0.0.1:8080/api/health"
