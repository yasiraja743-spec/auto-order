# ONYX Docker VPS NAT Provider

Provider API self-hosted untuk Ubuntu 24.04.

## Cara kerja

VPS Ubuntu 24.04 milik Anda menjalankan Docker. API ini membuat container Ubuntu 24.04 dan meneruskan port publik provider ke port SSH container.

Contoh:

    Public VPS IP: 152.55.181.59
    NAT port:      20001

Pembeli memakai:

    IP:       152.55.181.59
    Port:     20001
    Username: root
    Password: luciferXkyro

## Install

Upload folder ini ke VPS provider, lalu:

    cd onyx-provider
    chmod +x install.sh
    sudo ./install.sh

Edit `config.js`:

    PUBLIC_IP: "IP_PUBLIK_PROVIDER",
    API_KEY: "buat-key-random-yang-panjang",

Jalankan:

    npm start

## API

Semua endpoint membutuhkan:

    X-API-Key: API_KEY

Health:

    GET /api/health

Create:

    POST /api/vps/create

List:

    GET /api/vps

Detail:

    GET /api/vps/VPS_ID

Delete:

    DELETE /api/vps/VPS_ID

Contoh create:

    curl -X POST \
      -H "X-API-Key: YOUR_KEY" \
      http://127.0.0.1:8080/api/vps/create

Response:

    {
      "success": true,
      "vps": {
        "id": "vps-...",
        "ip": "152.55.181.59",
        "port": 20001,
        "username": "root",
        "password": "luciferXkyro",
        "status": "running"
      }
    }

## Hubungkan bot

Di `config.js` bot ONYX, arahkan provisioning ke endpoint:

    http://IP_PROVIDER:8080/api/vps/create

dan kirim header:

    X-API-Key: API_KEY_PROVIDER

## Keamanan

Jangan membuka Docker socket (`/var/run/docker.sock`) ke internet.

API sebaiknya hanya bisa diakses bot/provider network atau dipasang di belakang firewall/reverse proxy.

Ganti API_KEY default sebelum menjalankan provider.

## Catatan

Ini adalah container VPS NAT, bukan KVM VM. Resource limit diatur melalui Docker.

Disk limit `DISK_LIMIT` di config disiapkan sebagai parameter kebijakan, tetapi Docker tidak menerapkan quota filesystem universal hanya dari flag tersebut pada semua storage driver. Untuk quota disk yang benar-benar keras, gunakan storage driver/filesystem yang mendukung quota atau mekanisme volume quota terpisah.
