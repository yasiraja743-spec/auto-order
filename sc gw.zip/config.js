module.exports = {
  BOT_TOKEN: "8422306366:AAHaNR6_anWv-6q4EOY3rS5nr6Q-Od2h__c",
  ADMIN_ID: "8910103977",

  FORCE_CHANNEL: "@onyxkyro",
  LOG_CHANNEL: "@onyxkyro",

  VPS_PRICE: 500,
  VPS_PASSWORD: "luciferXkyro",
  DEVELOPER: "@darkluclfer",

  PUBLIC_IP: "152.55.180.252",

  // Resource limit per customer container
  MEMORY: "500g",
  CPU: "32.0",

  // NAT SSH port range
  PORT_START: 20000,
  PORT_END: 30000,

  DOCKER_IMAGE: "onyx-vps:ubuntu24",
  DATA_FILE: "./data/vps.json"
};
