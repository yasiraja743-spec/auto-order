#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo "Run: sudo bash install.sh"; exit 1; fi
apt-get update
apt-get install -y docker.io nodejs npm
systemctl enable --now docker
npm install --omit=dev
docker build -t onyx-vps:ubuntu24 docker
echo "Selesai. Jalankan: npm start"
