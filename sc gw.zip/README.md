# ONYX AUTO ORDER ALL-IN-ONE

Bot Telegram dan Docker provider sudah digabung dalam satu project.

## Install Ubuntu 24.04

    unzip ONYX-AUTO-ORDER-ALL-IN-ONE.zip
    cd ONYX-AUTO-ORDER-ALL-IN-ONE
    chmod +x install.sh
    sudo ./install.sh
    npm start

Semua provisioning dilakukan langsung oleh `provision.js`, jadi tidak ada provider API/port 8080/API key lagi.

Edit `config.js` jika perlu.

## Resource

Container default:
- RAM: 500 GB
- CPU: 32 core
- Password: luciferXkyro
- Public IP: 152.55.180.252

RAM/CPU adalah limit Docker per container. Host harus memiliki resource tersebut.

## Security

Token yang ada di config berasal dari token yang diberikan saat pembuatan project. Karena token pernah dikirim ke chat, revoke/regenerate token melalui BotFather setelah instalasi, lalu ganti `BOT_TOKEN` di `config.js`.
