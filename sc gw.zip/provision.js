const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const config = require("./config");

const file = path.resolve(config.DATA_FILE);
fs.mkdirSync(path.dirname(file), { recursive: true });
if (!fs.existsSync(file)) fs.writeFileSync(file, "[]");

function run(args) {
  return new Promise((resolve, reject) => {
    execFile("docker", args, {timeout: 180000, maxBuffer: 1024*1024}, (err, stdout, stderr) => {
      if (err) { err.stdout = stdout; err.stderr = stderr; reject(err); }
      else resolve(stdout.trim());
    });
  });
}

function load() {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return []; }
}
function save(x) {
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(x, null, 2));
  fs.renameSync(tmp, file);
}

async function ensureImage() {
  try { await run(["image", "inspect", config.DOCKER_IMAGE]); }
  catch { await run(["build", "-t", config.DOCKER_IMAGE, path.resolve(__dirname, "docker")]); }
}

async function freePort(items) {
  const used = new Set(items.map(v => Number(v.port)));
  const listening = await run(["ps", "-a", "--format", "{{.Ports}}"]).catch(() => "");
  for (let p=config.PORT_START; p<=config.PORT_END; p++) {
    if (used.has(p)) continue;
    if (!listening.includes(`:${p}->`)) return p;
  }
  throw new Error("NAT port range is full");
}

async function createVps() {
  const items = load();
  await ensureImage();
  const port = await freePort(items);
  const id = "vps-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2,8);
  const name = "onyx-" + id;

  await run([
    "run","-d","--name",name,"--hostname",name,
    "--restart","unless-stopped",
    "--memory",config.MEMORY,
    "--cpus",config.CPU,
    "--pids-limit","256",
    "-p",`${port}:22`,
    config.DOCKER_IMAGE
  ]);

  const record = {
    id, container:name, ip:config.PUBLIC_IP, port,
    username:"root", password:config.VPS_PASSWORD,
    memory:config.MEMORY, cpu:config.CPU,
    status:"running", createdAt:new Date().toISOString()
  };
  items.push(record); save(items);
  return record;
}

async function deleteVps(id) {
  const items=load();
  const v=items.find(x=>x.id===id);
  if(!v) throw new Error("VPS tidak ditemukan");
  await run(["rm","-f",v.container]).catch(()=>{});
  save(items.filter(x=>x.id!==id));
  return v;
}

module.exports={createVps,deleteVps};
