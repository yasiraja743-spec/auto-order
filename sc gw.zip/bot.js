const axios = require("axios");
const fs = require("fs");
const path = require("path");
const config = require("./config");
const { createVps } = require("./provision");

const API=`https://api.telegram.org/bot${config.BOT_TOKEN}`;
const ordersFile=path.resolve("./data/orders.json");
if(!fs.existsSync(ordersFile)) fs.writeFileSync(ordersFile,"[]");
const sessions=new Map();

const esc=s=>String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const orders=()=>JSON.parse(fs.readFileSync(ordersFile,"utf8"));
const save=x=>fs.writeFileSync(ordersFile,JSON.stringify(x,null,2));

async function tg(method,data={}) {
  const r=await axios.post(`${API}/${method}`,data,{timeout:60000});
  if(!r.data.ok) throw Error(r.data.description);
  return r.data.result;
}
async function msg(chat_id,text,extra={}) {
  return tg("sendMessage",{chat_id,text,parse_mode:"HTML",...extra});
}
async function joined(id) {
  try {
    const r=await tg("getChatMember",{chat_id:config.FORCE_CHANNEL,user_id:id});
    return ["creator","administrator","member"].includes(r.status);
  } catch { return false; }
}
async function menu(chat,user) {
  return tg("sendPhoto",{
    chat_id:chat,
    photo:"https://files.catbox.moe/9cs2g7.jpg",
    caption:`<b>AUTO ORDER VPS NAT</b>

<b>ONYX VPS AUTO ORDER</b>
HARGA SETIAP VPS <b>Rp${config.VPS_PRICE}</b>
ADA TOOLS BUAT VPS KALIAN

Halo <b>${esc(user.first_name||user.username||"User")}</b> 👋`,
    parse_mode:"HTML",
    reply_markup:{inline_keyboard:[
      [{text:"🛒 Buy VPS",callback_data:"buy",style:"primary"},
       {text:"🛠 Tools VPS",callback_data:"tools",style:"primary"}]
    ]}
  });
}
async function start(chat,user) {
  if(!await joined(user.id))
    return msg(chat,`<b>🔒 JOIN CHANNEL DULU</b>

Join <b>${config.FORCE_CHANNEL}</b> untuk menggunakan bot.`,{
      reply_markup:{inline_keyboard:[
        [{text:"📢 Join Channel",url:"https://t.me/onyxkyro"}],
        [{text:"✅ Sudah Join",callback_data:"check"}]
      ]}
    });
  return menu(chat,user);
}

async function handle(m) {
  const chat=m.chat.id, user=m.from, text=m.text||"";
  const s=sessions.get(chat);

  if(text==="/start") return start(chat,user);
  if(text==="/orders" && String(user.id)===String(config.ADMIN_ID))
    return msg(chat,orders().slice(-20).reverse().map(o=>`${o.id} | ${o.status} | @${o.username}`).join("\n")||"Belum ada order.");

  if(s?.type==="proof" && (m.photo||m.document)) {
    const o={id:"ORD-"+Date.now(),userId:user.id,username:user.username||"-",name:user.first_name||"-",price:config.VPS_PRICE,status:"waiting",createdAt:new Date().toISOString()};
    const all=orders(); all.push(o); save(all); sessions.delete(chat);
    await msg(chat,"✅ Bukti pembayaran diterima. Tunggu admin melakukan verifikasi.");
    return msg(config.ADMIN_ID,`<b>💰 PEMBAYARAN BARU</b>

Order: <code>${o.id}</code>
User: @${esc(o.username)}
ID: <code>${o.userId}</code>
Harga: <b>Rp${o.price}</b>`,{reply_markup:{inline_keyboard:[
      [{text:"✅ ACCEPT",callback_data:`accept:${o.id}`,style:"success"},
       {text:"❌ REJECT",callback_data:`reject:${o.id}`,style:"danger"}]
    ]}});
  }
  if(s?.type==="proof") return msg(chat,"Kirim bukti pembayaran berupa foto/dokumen.");

  if(s?.type==="tools_ip"&&text){s.ip=text.trim();s.type="tools_port";return msg(chat,"Masukkan port SSH VPS:");}
  if(s?.type==="tools_port"&&text){const p=Number(text);if(!Number.isInteger(p)||p<1||p>65535)return msg(chat,"Port tidak valid.");s.port=p;s.type="tools_password";return msg(chat,"Masukkan password VPS:");}
  if(s?.type==="tools_password"&&text){s.password=text;s.type="tools_file";return msg(chat,"Sekarang kirim file yang mau di-upload.");}
  if(s?.type==="tools_file"&&m.document)return msg(chat,"Upload tools siap diproses. Integrasi SFTP target dapat ditambahkan setelah endpoint upload ditentukan.");
}

async function callback(q) {
  await tg("answerCallbackQuery",{callback_query_id:q.id});
  const chat=q.message.chat.id, d=q.data;

  if(d==="check") return start(chat,q.from);
  if(d==="buy"){
    sessions.set(chat,{type:"proof"});
    return tg("sendPhoto",{chat_id:chat,photo:"https://files.catbox.moe/flmxr0.jpg",caption:`<b>QRIS PEMBAYARAN</b>

Harga VPS: <b>Rp${config.VPS_PRICE}</b>

Setelah bayar, kirim bukti pembayaran.`,parse_mode:"HTML"});
  }
  if(d==="tools"){sessions.set(chat,{type:"tools_ip"});return msg(chat,"<b>🛠 TOOLS VPS</b>\n\nMasukkan IP VPS:");}
  if(!d.startsWith("accept:")&&!d.startsWith("reject:"))return;
  if(String(q.from.id)!==String(config.ADMIN_ID))return msg(chat,"Unauthorized.");

  const [action,id]=d.split(":"); const all=orders(); const o=all.find(x=>x.id===id);
  if(!o)return msg(chat,"Order tidak ditemukan.");
  if(action==="reject"){o.status="rejected";save(all);await msg(o.userId,`❌ Order <code>${o.id}</code> ditolak.`);return msg(chat,"Order ditolak.");}
  if(o.status!=="waiting")return msg(chat,"Order sudah diproses.");

  o.status="provisioning";save(all);
  await msg(chat,"⏳ Membuat VPS Docker...");
  try{
    const v=await createVps();
    o.status="completed";o.vpsId=v.id;save(all);
    await msg(o.userId,`<b>🎉 VPS BERHASIL DIBUAT</b>

<b>VPS DATA</b>
IP: <code>${v.ip}</code>
Port: <code>${v.port}</code>
Username: <code>${v.username}</code>
Password: <code>${v.password}</code>

Terima kasih sudah order di <b>ONYX VPS AUTO ORDER</b>.`);
    await msg(config.LOG_CHANNEL,`<b>💰 PEMBAYARAN BERHASIL</b>

Terimakasih kak @${esc(o.username)}
telah order di bot kami.

Barang yang dibeli: <b>VPS NAT</b>
Harga: <b>Rp${o.price}</b>`);
    return msg(chat,`✅ ${id} selesai. VPS ${v.id} berhasil dibuat.`);
  }catch(e){
    o.status="provision_failed";o.error=e.message;save(all);
    await msg(o.userId,"⚠️ Pembayaran diterima, tetapi provisioning gagal. Admin akan mengecek server.");
    return msg(chat,"❌ Gagal membuat VPS: "+esc(e.message));
  }
}

(async()=>{
  console.log("ONYX Auto Order + Docker Provider berjalan...");
  await tg("deleteWebhook",{drop_pending_updates:false}).catch(()=>{});
  let offset=0;
  while(true){
    try{
      const us=await tg("getUpdates",{offset,timeout:50,allowed_updates:["message","callback_query"]});
      for(const u of us){
        offset=u.update_id+1;
        if(u.message)await handle(u.message).catch(console.error);
        if(u.callback_query)await callback(u.callback_query).catch(console.error);
      }
    }catch(e){console.error("Polling:",e.message);await new Promise(r=>setTimeout(r,3000));}
  }
})();
